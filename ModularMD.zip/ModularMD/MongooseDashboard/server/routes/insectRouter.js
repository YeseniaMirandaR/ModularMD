const express = require('express');
const InsectRouter = express.Router();
const {InsectsController} = require ('./../controllers/insectsController');

InsectRouter
    .get('/', InsectsController.showDashboard);//

InsectRouter
//create
    .post('/insects', InsectsController.createInsectPost);

InsectRouter
// new form
    .get('/insects/new', InsectsController.createInsectGet);//

InsectRouter
//show
    .get('/insects/:id', InsectsController.showInsect);//

InsectRouter
//edit form
    .get('/insects/edit/:id/', InsectsController.editInsectGet);//

InsectRouter
    .post('/insects/:id', InsectsController.updateInsect );

InsectRouter
// delete
    .post('/insects/destroy/:id/', InsectsController.deleteInsect);

module.exports = {InsectRouter};