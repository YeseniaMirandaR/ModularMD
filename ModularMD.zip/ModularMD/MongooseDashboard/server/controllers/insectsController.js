
const{InsectModel} = require('./../models/insectModel');

const InsectsController = {

    showDashboard: function(req, res){
        InsectModel
        .showDashboard()
        .then(results=> {res.render('index', { insects: results });})
        .catch(err => {console.log(err);})
    },

        createInsectPost: function(req, res){
            InsectModel
            .createInsectPost(req.body)
            .then(result=> {res.redirect('/');})
            .catch(err=> {console.log(err);})
    },

    createInsectGet: function(req, res){
        res.render('new');
    },

    showInsect: function(req, res){
        InsectModel
        .showInsect({ _id: req.params.id }) 
        .then(response=>{res.render('show', { insect: response[0] });})   
        .catch(err => { console.log(err);})
            
    },

    editInsectGet: function(req, res){
        InsectModel
        .editInsectGet({ _id: req.params.id }) 
        .then(response=>{res.render('edit', { insect: response[0] });})   
        .catch(err => { console.log(err); }) 
            
    },

    updateInsect: function(req, res){
        console.log({ _id: req.params.id }, req.body);
        InsectModel
        .updateInsect({ _id: req.params.id }, req.body)
        .then(result =>{res.redirect('/');})
        .catch(err=> {console.log(err);})
    },

    deleteInsect: function(req, res){
        InsectModel
        .deleteInsect({ _id: req.params.id })
        .then(result=> {res.redirect('/');})
        .catch(err=> { console.log(err);})
    }
}

module.exports = {InsectsController};
