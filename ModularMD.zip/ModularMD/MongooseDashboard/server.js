// Dependencies
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const {InsectRouter} = require('./server/routes/insectRouter');
require('./server/config/database')
// Create express app
const app = express();

//To parse form data sent via HTTP POST
app.use(bodyParser.urlencoded({ extended: true }));

// Tell server where views are and what templating engine I'm using
app.set('views', path.join(__dirname, '/client/views'));
app.set('view engine', 'ejs');
app.use('/', InsectRouter);


app.listen(8080, function(){
  console.log("Running on ", 8080);
});
