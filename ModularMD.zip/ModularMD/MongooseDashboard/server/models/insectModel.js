const mongoose = require('mongoose');
const InsectSchema = new mongoose.Schema({
    commonName: {
        type: String,
        required: true,
    },
    scientificName: {
        type: String,
        required: true,
    },
    color: {
        type: String,
        required: true,
    }
});

const Insect = mongoose.model('insects', InsectSchema);

const InsectModel = {
    showDashboard: function(){
        return Insect.find();
    },//

    createInsectPost : function(rbody){
        return Insect.create(rbody);
    },//

    showInsect: function(id){
        return Insect.find(id);
    },//

    editInsectGet: function(id){
        return Insect.find(id);
    },//

    updateInsect: function(id, rbody){
        return Insect.updateOne(id, rbody);
    },

    deleteInsect: function(id){
        return Insect.remove(id);
    }
}

module.exports = {InsectModel};