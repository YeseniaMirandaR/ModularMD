const mongoose = require('mongoose');
// Create connection to database
mongoose.connect('mongodb://localhost/insect_db_modular', {useNewUrlParser: true});